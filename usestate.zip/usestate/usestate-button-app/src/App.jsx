import React, { useState } from 'react';

function App() {
  const [count, setCount] = useState(0); // Initial count = 0

  const handleClick = () => {
    setCount(count + 1); // Increase count by 1
  };

  return (
    <div style={styles.container}>
      <h1>useState Hook Example</h1>
      <h2>Count: {count}</h2>
      <button onClick={handleClick} style={styles.button}>
        Click Me
      </button>
    </div>
  );
}

const styles = {
  container: {
    textAlign: 'center',
    marginTop: '100px',
    fontFamily: 'Arial',
  },
  button: {
    padding: '10px 20px',
    fontSize: '16px',
    cursor: 'pointer',
  },
};

export default App;
