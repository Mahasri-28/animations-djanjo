import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [users, setUsers] = useState([]);
  const [searchName, setSearchName] = useState('');
  const [userDetails, setUserDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => {
    fetch('/users.json')
      .then((res) => res.json())
      .then((data) => {
        setUsers(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error loading users:', err);
        setLoading(false);
      });
  }, []);

  const handleSearch = () => {
    const found = users.find((user) =>
      user.name.toLowerCase().includes(searchName.toLowerCase().trim())
    );
    setUserDetails(found ? found : { notFound: true });
    setSuggestions([]);
  };

  const handleChange = (e) => {
    const value = e.target.value;
    setSearchName(value);

    if (value.trim() !== '') {
      const matches = users.filter((user) =>
        user.name.toLowerCase().includes(value.toLowerCase())
      );
      setSuggestions(matches);
    } else {
      setSuggestions([]);
    }
  };

  const handleSuggestionClick = (name) => {
    setSearchName(name);
    setSuggestions([]);
    handleSearch();
  };

  return (
    <div style={styles.container}>
      <h1>User Lookup</h1>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSearch();
        }}
        style={{ position: 'relative' }}
      >
        <input
          type="text"
          placeholder="Enter name"
          value={searchName}
          onChange={handleChange}
          style={styles.input}
        />
        <button type="submit" style={styles.button}>Search</button>

        {suggestions.length > 0 && (
          <ul className="slide-down" style={styles.suggestionsList}>
            {suggestions.map((user, index) => (
              <li
                key={index}
                style={styles.suggestionItem}
                onClick={() => handleSuggestionClick(user.name)}
              >
                {user.name}
              </li>
            ))}
          </ul>
        )}
      </form>

      {loading ? (
        <p>Loading...</p>
      ) : userDetails ? (
        <div className="fade-in" style={styles.result}>
          {userDetails.notFound ? (
            <p style={{ color: 'red' }}>User not found.</p>
          ) : (
            <>
              <h3>{userDetails.name}</h3>
              <p><strong>Email:</strong> {userDetails.email}</p>
              <p><strong>Phone:</strong> {userDetails.phone}</p>
              <p><strong>Website:</strong> {userDetails.website}</p>
            </>
          )}
        </div>
      ) : null}
    </div>
  );
}

const styles = {
  container: {
    fontFamily: 'Arial',
    textAlign: 'center',
    padding: '30px',
  },
  input: {
    padding: '10px',
    width: '250px',
    borderRadius: '4px',
    border: '1px solid #ccc',
    fontSize: '16px',
  },
  button: {
    padding: '10px 15px',
    marginLeft: '10px',
    fontSize: '16px',
    borderRadius: '4px',
    border: 'none',
    backgroundColor: '#007bff',
    color: 'white',
    cursor: 'pointer',
  },
  suggestionsList: {
    listStyleType: 'none',
    padding: '0',
    margin: '5px auto 0',
    width: '270px',
    textAlign: 'left',
    border: '1px solid #ccc',
    borderRadius: '4px',
    backgroundColor: 'black',
    position: 'absolute',
    left: '50%',
    transform: 'translateX(-50%)',
    zIndex: 1,
    maxHeight: '150px',
    overflowY: 'auto',
  },
  suggestionItem: {
    padding: '8px 10px',
    borderBottom: '1px solid #eee',
    cursor: 'pointer',
  },
  result: {
    marginTop: '30px',
    textAlign: 'center',
    padding: '15px',
    border: '1px solid #ddd',
    borderRadius: '6px',
    width: '300px',
    marginLeft: 'auto',
    marginRight: 'auto',
    backgroundColor: 'rgba',
  }
};

export default App;
